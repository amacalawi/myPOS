import React, { useState, useEffect } from "react";
import {
  IonApp,
  IonContent,
  IonHeader,
  IonToolbar,
  IonTitle,
  IonMenu,
  IonPage,
  IonButtons,
  IonMenuButton,
  IonList,
  IonItem,
  IonSplitPane,
} from "@ionic/react";
import { BrowserRouter as Router, Route } from "react-router-dom";

const Home: React.FC = () => <IonContent><h2>🏠 Home Page</h2></IonContent>;
const About: React.FC = () => <IonContent><h2>ℹ️ About Page</h2></IonContent>;
const Contact: React.FC = () => <IonContent><h2>📞 Contact Page</h2></IonContent>;

const AppShell: React.FC = () => {
  const [isDesktop, setIsDesktop] = useState(window.innerWidth > 768);

  useEffect(() => {
    const handleResize = () => setIsDesktop(window.innerWidth > 768);
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  return (
    <IonApp>
      <Router>
        {/* Sidebar Layout (Auto-Collapses on Mobile) */}
        <IonSplitPane contentId="main-content" when={isDesktop ? true : false}>
          <IonMenu contentId="main-content" type={isDesktop ? "sidebar" : "overlay"}>
            <IonContent>
              <IonList>
                <IonItem routerLink="/home">🏠 Home</IonItem>
                <IonItem routerLink="/about">ℹ️ About</IonItem>
                <IonItem routerLink="/contact">📞 Contact</IonItem>
              </IonList>
            </IonContent>
          </IonMenu>

          {/* Main Content */}
          <IonPage id="main-content">
            <IonHeader>
              <IonToolbar>
                {!isDesktop && (
                  <IonButtons slot="start">
                    <IonMenuButton />
                  </IonButtons>
                )}
                <IonTitle>🖥️ Desktop Sidebar Layout</IonTitle>
              </IonToolbar>
            </IonHeader>
            <IonContent>
                sasa
            </IonContent>
          </IonPage>
        </IonSplitPane>
      </Router>
    </IonApp>
  );
};

export default AppShell;
